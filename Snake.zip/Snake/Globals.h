#include <windows.h>
#include <SDL.h>
#include <GL/gl.h>
#include <SDL_mixer.h>

#define CUBESIZE 30
#define CELLSIZE 36
#define MATRIXSIZE 20

#pragma comment(lib, "opengl32.lib")

struct SPoint{
    int x,y;
    struct SPoint *next;
};
typedef struct SPoint SPoint;

enum state {loading, menu, ingame, paused, highscores};
typedef enum state state;

typedef struct {
    Mix_Chunk *Snd;
    int Chnl;
} Sound;

typedef struct {
    int Running;
    SDL_Surface* SDisplay;
    int dx, dy;
    SPoint Food;
    SPoint *Head;
    int KeyPressed;
    state State;
    int Timer;
    int Speed;
    //    Sound MainTheme;
    Mix_Music *Music;
    Sound Nyam;
} SApp;

/*--- EVENT PROCESSING --- */
void SOnKeyDown(SApp *, SDLKey, SDLMod, Uint16);
void SProcessEvent(SApp *, SDL_Event *);

/*--- GRAPHICS ---*/
void SRender(SApp *);
void SInitGraphics(void);

/*--- OpenGL Drawing ---*/
void SCube(int, int, int);
void SGrid(void);

/*--- Sound and music! ---*/
void SInitSound(SApp *);
void SPlaySound(Sound *);
